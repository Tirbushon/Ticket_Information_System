#pragma once
class Building
{
};

